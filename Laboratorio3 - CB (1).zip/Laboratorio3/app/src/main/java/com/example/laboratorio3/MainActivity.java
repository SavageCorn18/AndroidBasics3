package com.example.laboratorio3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.laboratorio3.controller.PersonaController;
import com.example.laboratorio3.entity.Persona;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText txt1;
    private EditText txt2;
    private Button btn1;
    private ListView listViewPersons;
    private PersonaController personController;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> personList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        btn1 = findViewById(R.id.btn1);
        listViewPersons = findViewById(R.id.listViewPersons);

        personController = new PersonaController(this);
        personList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, personList);
        listViewPersons.setAdapter(adapter);

        btn1.setOnClickListener(v -> savePersonData());

        // Cargar los datos existentes al iniciar la actividad
        loadPersons();
    }

    private void savePersonData() {
        int id = Integer.parseInt(txt1.getText().toString());
        String name = txt2.getText().toString();

        personController.insertPerson(id, name);
        Toast.makeText(this, "Datos de persona guardados en la base de datos", Toast.LENGTH_SHORT).show();

        // Actualizar la lista después de guardar los datos
        loadPersons();
    }

    private void loadPersons() {
        personList.clear();
        ArrayList<Persona> persons = personController.getAllPersons();
        for (Persona person : persons) {
            personList.add("ID: " + person.getId() + ", Nombre: " + person.getName());
        }
        adapter.notifyDataSetChanged();
    }
}

