package com.example.laboratorio3.controller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.laboratorio3.entity.Persona;
import com.example.laboratorio3.model.DatabaseHelper;

import java.util.ArrayList;

public class PersonaController {
    private DatabaseHelper dbHelper;

    public PersonaController(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void insertPerson(int id, String name) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id", id);
        values.put("name", name);
        db.insert("persons", null, values);
        db.close();
    }

    public ArrayList<Persona> getAllPersons() {
        ArrayList<Persona> personList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM persons", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String name = cursor.getString(cursor.getColumnIndex("name"));
                Persona person = new Persona(id, name);
                personList.add(person);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return personList;
    }
}
